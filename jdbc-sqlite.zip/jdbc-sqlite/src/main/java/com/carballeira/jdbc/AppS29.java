package com.carballeira.jdbc;

public class AppS29 {
	public static void main (String [] Args) {
		
	}
}
